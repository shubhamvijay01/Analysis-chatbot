# Deployment Guide

## Vercel Deployment (Recommended)

### Steps

1. **Push to GitHub**
2. **Import to Vercel** 
3. **Add Environment Variables**: OPENAI_API_KEY
4. **Deploy**

Your app will be live in 2-3 minutes!
