# Screenshots

This folder contains UI screenshots for documentation.

## Included Screenshots

1. **chatbot-main.png** - Main chatbot interface
2. **chat-response.png** - Example AI response  
3. **mobile-view.png** - Mobile responsive view

These images are referenced in the main README.md file.
